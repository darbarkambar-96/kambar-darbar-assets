#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/shubhamrane/Documents/Flutter_SDKs/flutter_SDK_3.35.6"
export "FLUTTER_APPLICATION_PATH=/Users/shubhamrane/Desktop/MyProjects/kambardarbar_mobile_app"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.5"
export "FLUTTER_BUILD_NUMBER=1.0.5"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
